PM.Sessions.register();

PM.Sessions.setLabel('ID_BLOCKER_MSG', PM.Sessions.getCookie('PM-Warning'));